<?php

require_once '../modele/AuthModel.php';

if (isset($_POST['pseudo']) && isset($_POST['mdp'])) {
    $pseudo = $_POST['pseudo'];
    $mdp = $_POST['mdp'];

    $model = new AuthModel("localhost", "root", "", "dit2");
    $authenticated = $model->checkCredentials($pseudo, $mdp);
    $model->closeConnection();

    if ($authenticated) {
        header("Location: ../vue/index.php");
        exit();
    } else {
        echo "Pseudo ou mot de passe incorrect.";
    }
}
?>