<?php $client = new SoapClient('http://localhost:1234/GestionEtudiant?wsdl');?>
<!DOCTYPE html>
<htm1> 
<head> 
    <meta charset="utf-8">
    <title>Liste des étudiants</title> 
    <style type="text/css">

       form{
            width: 50%;
            margin: auto;
       }

    </style> 
</head> 
<body> 
    <form method="post"> 
        <fieldset>
            <legend>Ajout d'un étudiant</legend>
            <label>Nom</label>
            <input type="text" name="nom">
            <label>Prénom</label>
            <input type="text" name="prenom">
            <input type="submit" value="Ajouter">
        </fieldset>
    </form>

<?php
    If (isset($_POST['nom'], $_POST['prenom']))
    {
        $parametres = array(
            'nom' => $_POST['nom'],
            'prenom' => $_POST['prenom']
        );
       $client->__soapCall('ajouter',array($parametres));
    }

?>

<h1 align="center">Liste des étudiant</h1>
<?php
    $etudiants = $client->__soapCall('lister',array());

    if (!empty($etudiants->return))
    {?>
        <table align="center" border="1" cellspacing="0" cellspacing="5">
            <tr>
                <th>ID</th>
                <th>Nom</th>
                <th>Prénom</th>
        </tr><?php
        if (!is_array($etudiants->return))
        {?>
            <tr>
                <td><?= $etudiants->return->id ?></td>
                <td><?= $etudiants->return->nom ?></td>
                <td><?= $etudiants->return->prenom ?></td>
            </tr><?php
        }
        else
        {
            foreach ($etudiants->return as $etudiant)
            {?>
                 <tr>
                    <td><?= $etudiant->id ?></td> 
                    <td><?= $etudiant->nom ?></td> 
                    <td><?= $etudiant->prenom ?></td>
            </tr><?php

            }
        }?>
    </table><?php     

}
else
{
    echo '<p align="center"> La liste des étudiants est vide</p>';
}
?>
</body>
</html>